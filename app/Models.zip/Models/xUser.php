<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    use HasFactory;
    protected $fillable = [
        'firstname',
        'middlename',
        'lastname',
        'gender',
        'email',
        'email_verify_status',
        'password',
        'google_id',
        'phone',
        'is_terms_conditions',
        'title_designation',
        'company_name',
        'location',
        'country',
        'state',
        'city',
        'dob',
        'fb',
        'wap',
        'tw',
        'lnkd',
        'connection_code',
        'photo_url',
        'user_type',
    ];
}
